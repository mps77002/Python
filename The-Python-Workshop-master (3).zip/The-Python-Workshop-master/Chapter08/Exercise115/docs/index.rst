.. divisible documentation master file, created by
   sphinx-quickstart on Wed May  8 21:41:28 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to divisible's documentation!
=====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:


.. automodule:: divisible
   :members:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
