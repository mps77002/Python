
def is_divisible(x, y):
    if x % y == 0:
        return True
    else:
        return False
