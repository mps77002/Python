"""
This script prints the current system date.
"""
import datetime 
print(datetime.date.today())