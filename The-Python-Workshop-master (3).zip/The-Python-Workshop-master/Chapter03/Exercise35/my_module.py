import math

def compute(numbers):
    return([math.factorial(n) for n in numbers])
